package uz.master.demotest.dto.test;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RequestTestDto {
    private Long id;
}
