package uz.master.demotest.dto;

public interface BaseDto {
}
