package uz.master.demotest.dto.test;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TestIntroductionDto {
    private Long id;
    private String name;
    private Integer numberOfQuestion;
    private Integer timeForAllQues;

}
