package uz.master.demotest.mappers;

import org.mapstruct.Mapper;
import uz.master.demotest.entity.test.Question;

@Mapper(componentModel = "spring")
public interface QuestionMapper {



}
