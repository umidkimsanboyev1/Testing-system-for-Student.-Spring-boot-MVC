package uz.master.demotest.mappers;

import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public class AuthUserMapper {



}
