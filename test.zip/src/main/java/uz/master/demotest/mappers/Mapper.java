package uz.master.demotest.mappers;

public interface Mapper {
}
