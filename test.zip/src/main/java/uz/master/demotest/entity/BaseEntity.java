package uz.master.demotest.entity;

public interface BaseEntity {
}
