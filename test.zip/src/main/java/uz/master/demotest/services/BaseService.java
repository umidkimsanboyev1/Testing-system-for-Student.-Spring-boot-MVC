package uz.master.demotest.services;

public interface BaseService {
}
