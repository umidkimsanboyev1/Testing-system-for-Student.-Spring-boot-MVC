package uz.master.demotest.utils;



import java.nio.file.Path;
import java.nio.file.Paths;

public class FileUploadUtils {

    public static final String UPLOAD_DIRECTORY = "/uploads/";

    public static final Path UPLOAD_DIRECTORY_PATH= Paths.get(UPLOAD_DIRECTORY);

}
