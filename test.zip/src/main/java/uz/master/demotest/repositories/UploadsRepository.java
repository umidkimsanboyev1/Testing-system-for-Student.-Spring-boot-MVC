package uz.master.demotest.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UploadsRepository extends JpaRepository<uz.master.demotest.entity.action.Uploads, Long> {
}
