package uz.master.demotest.validator;

public interface Validator {
}
